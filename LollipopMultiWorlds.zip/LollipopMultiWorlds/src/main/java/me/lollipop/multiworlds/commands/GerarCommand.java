package me.lollipop.multiworlds.commands;

public class GerarCommand {

}
