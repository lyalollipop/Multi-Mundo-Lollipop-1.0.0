package me.lollipop.multiworlds.commands;

import me.lollipop.multiworlds.LollipopMultiWorlds;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class SetWarpCommand implements CommandExecutor {
    private final LollipopMultiWorlds plugin;
    public SetWarpCommand(LollipopMultiWorlds plugin) { this.plugin = plugin; }
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Player p = (Player) sender;
        plugin.getWarpManager().setWarp(args[0], p.getLocation(), args[1], false);
        p.sendMessage("§aWarp criada!");
        return true;
    }
}