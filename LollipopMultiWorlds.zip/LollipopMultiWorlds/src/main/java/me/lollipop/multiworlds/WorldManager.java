package me.lollipop.multiworlds;

import org.bukkit.Bukkit;
import org.bukkit.World;
import java.io.File;

public class WorldManager {
    public static void deleteWorld(String name) {
        World world = Bukkit.getWorld(name);
        if (world != null) {
            Bukkit.unloadWorld(world, false);
        }
        File folder = new File(Bukkit.getWorldContainer(), name);
        if (folder.exists()) {
            deleteDirectory(folder);
        }
    }

    private static void deleteDirectory(File path) {
        if (path.exists()) {
            File[] files = path.listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f.isDirectory()) deleteDirectory(f);
                    else f.delete();
                }
            }
            path.delete();
        }
    }
}