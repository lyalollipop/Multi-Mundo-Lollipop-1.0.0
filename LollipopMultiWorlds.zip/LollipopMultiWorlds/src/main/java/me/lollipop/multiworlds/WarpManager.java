package me.lollipop.multiworlds;

import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;

public class WarpManager {
    private final LollipopMultiWorlds plugin;
    private File file;
    private YamlConfiguration config;

    // Construtor aceitando o plugin
    public WarpManager(LollipopMultiWorlds plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "warps.yml");
        if (!file.exists()) {
            try { file.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        }
        this.config = YamlConfiguration.loadConfiguration(file);
    }

    // Método setWarp com 4 argumentos
    public void setWarp(String name, Location loc, String itemType, boolean isOp) {
        config.set("warps." + name + ".loc", loc);
        config.set("warps." + name + ".item", itemType);
        config.set("warps." + name + ".op", isOp);
        try { config.save(file); } catch (IOException e) { e.printStackTrace(); }
    }

    public Location getWarpLocation(String name) { 
        return config.getLocation("warps." + name + ".loc"); 
    }
}