package me.lollipop.multiworlds.listeners;

import me.lollipop.multiworlds.LollipopMultiWorlds;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class MenuListener implements Listener {
    private final LollipopMultiWorlds plugin;
    public MenuListener(LollipopMultiWorlds plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!event.getView().getTitle().equals("§1Menu de Warps")) return;
        event.setCancelled(true);
        Player player = (Player) event.getWhoClicked();
        String warpName = ChatColor.stripColor(event.getCurrentItem().getItemMeta().getDisplayName());
        player.closeInventory();
        player.teleport(plugin.getWarpManager().getWarpLocation(warpName));
    }
}