package me.lollipop.multiworlds;

import me.lollipop.multiworlds.commands.*;
import me.lollipop.multiworlds.listeners.*;
import org.bukkit.plugin.java.JavaPlugin;

public class LollipopMultiWorlds extends JavaPlugin {
    private WarpManager warpManager;

    @Override
    public void onEnable() {
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        
        // Passando 'this' para o gerenciador
        this.warpManager = new WarpManager(this);

        // Registros corrigidos
        getCommand("gerar").setExecutor(new GerarCommand());
        getCommand("setwarp").setExecutor(new SetWarpCommand(this));
        
        // Assegure-se de que ResetWorldCommand existe no pacote commands
        getCommand("attnether").setExecutor(new ResetWorldCommand());
        getCommand("attend").setExecutor(new ResetWorldCommand());

        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getLogger().info("Lollipop Multi Worlds ativado!");
    }

    public WarpManager getWarpManager() { return this.warpManager; }
}